
import React from 'react';

export default function App() {
  return (
    <div style={{ padding: 20, fontFamily: 'sans-serif' }}>
      <h1>Welcome to EduQuest</h1>
      <p>This is your educational adventure platform. Stay tuned!</p>
    </div>
  );
}
